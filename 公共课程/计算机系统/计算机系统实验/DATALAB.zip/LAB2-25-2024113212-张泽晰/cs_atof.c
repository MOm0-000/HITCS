#include <stdio.h>
#include <float.h>  // 用于 FLT_MAX, FLT_MIN
#include <math.h>   // 用于 INFINITY
#include <ctype.h>  // 用于 isdigit
#include <string.h>
int isfnum(char *s)
{
    int k=0;
    while(k<strlen(s))
    {
        if(k==0)
        {
            if(!isdigit(s[0])&&s[0]!='+'&&s[0]!='-'){return 0;}
        }
        else
        {
            if(!isdigit(s[k])&&s[k]!='.'){return 0;}
        }
        k++;
    }
    return 1;
}
int isenum(char *s)
{
    int k=0;
    int flag=0;
    int num=0;
    while(k<strlen(s))
    {
        if(k==0)
        {
            if(!isdigit(s[0])&&s[0]!='+'&&s[0]!='-'){return 0;}
        }
        else
        {
            if(!isdigit(s[k])&&s[k]!='.'&&s[k]!='e'&&s[k]!='E'&&s[0]!='+'&&s[0]!='-'){return 0;}
        }
        if(s[k]=='e'||s[k]=='E'){num++;flag=1;}
        k++;
    }
    if(num==1&&flag==1)return 1;
    return 0;
}

// 比较两个小数字符串 a 和 b（不含科学计数法）
// 返回：-1 if a < b, 0 if a == b, 1 if a > b
int compare(const char* a, const char* b)
{
    if(a==NULL&&b==NULL){return 0;}
    if(a!=NULL&&b==NULL){return -1;}
    if(a==NULL&&b!=NULL){return 1;}

    // 1. 处理符号
    int sign_a = 1, sign_b = 1;
    int ia = 0, ib = 0;

    if (a[0] == '+') ia++;
    else if (a[0] == '-') { sign_a = -1; ia++; }

    if (b[0] == '+') ib++;
    else if (b[0] == '-') { sign_b = -1; ib++; }

    // 2. 符号不同：正 > 负（注意 -0.0 特例，但字符串通常为 "0" 或 "-0"）
    if (sign_a != sign_b)
    {
        // 检查是否都是零（如 "0" vs "-0"）
        int a_is_zero = 1, b_is_zero = 1;
        for (int i = ia; a[i]; i++)
        {
            if (a[i] != '0' && a[i] != '.') { a_is_zero = 0; break; }
        }
        for (int i = ib; b[i]; i++)
        {
            if (b[i] != '0' && b[i] != '.') { b_is_zero = 0; break; }
        }
        if (a_is_zero && b_is_zero) return 0; // "-0" == "0"
        if(sign_a>sign_b)return 1;
        else if(sign_a<sign_b)return -1;
    }

    // 3. 符号相同：比较绝对值
    // 找小数点位置
    const char *dot_a = strchr(a + ia, '.');
    const char *dot_b = strchr(b + ib, '.');
    int len_int_a=0,len_int_b=0;
    if(dot_a==NULL){len_int_a=(int)strlen(a + ia);}
    else{len_int_a=(int)(dot_a-(a+ia));}
    if(dot_b==NULL){len_int_b=(int)strlen(b + ib);}
    else{len_int_b=(int)(dot_b-(b+ib));}

    // 3.1 比较整数部分长度
    if (len_int_a != len_int_b)
    {
        if(sign_a==1&&len_int_a>len_int_b){return 1;}
        if(sign_a==1&&len_int_a<len_int_b){return -1;}
        if(sign_a==-1&&len_int_a>len_int_b){return -1;}
        if(sign_a==-1&&len_int_a<len_int_b){return 1;}
    }

    // 3.2 整数部分长度相同：逐位比较
    const char* int_a_start = a + ia;
    const char* int_b_start = b + ib;

    for(int i=0;i<len_int_a;i++)
    {
        if(*(a+ia+i)>*(b+ib+i)){return 1;}
        else if(*(a+ia+i)<*(b+ib+i)){return -1;}
    }

    // 3.3 整数部分相等：比较小数部分
    const char* frac_a = dot_a ? dot_a + 1 : "";
    const char* frac_b = dot_b ? dot_b + 1 : "";

    size_t len_frac_a = strlen(frac_a);
    size_t len_frac_b = strlen(frac_b);
    size_t min_len = (len_frac_a < len_frac_b) ? len_frac_a : len_frac_b;

     for(int i=0;i<min_len;i++)
    {
        if(*(frac_a+i)>*(frac_b+i)){return 1;}
        else if(*(frac_a+i)<*(frac_b+i)){return -1;}
    }

    // 小数部分前缀相同：较长者更大（因后面是额外数字）
    if (len_frac_a != len_frac_b)
    {
        char extra = (len_frac_a > len_frac_b) ? frac_a[min_len] : frac_b[min_len];
        if (extra == '0')
        {
            // 需检查剩余是否全零
            const char* rest = (len_frac_a > len_frac_b) ? frac_a + min_len : frac_b + min_len;
            for (size_t i = 0; rest[i]; i++)
            {
                if (rest[i] != '0')
                {
                    if(len_frac_a>len_frac_b&&sign_a==1){return 1;}
                    if(len_frac_a>len_frac_b&&sign_a==-1){return -1;}
                    if(len_frac_a<len_frac_b&&sign_a==1){return -1;}
                    if(len_frac_a<len_frac_b&&sign_a==-1){return 1;}
                }
            }
            return 0; // 剩余全零，相等
        }
        else
        {
            if(len_frac_a>len_frac_b&&sign_a==1){return 1;}
            if(len_frac_a>len_frac_b&&sign_a==-1){return -1;}
            if(len_frac_a<len_frac_b&&sign_a==1){return -1;}
            if(len_frac_a<len_frac_b&&sign_a==-1){return 1;}
        }
    }

    return 0; // 完全相等
}

float cs_atof(char *s)
{
    if(s==NULL){return 0.0f;}
    if(!isfnum(s)&&!isenum(s)){return 0.0f;}
    if(*s=='0'&&*(s+1)=='\0'){return 0.0f;}
    else if(*s=='+'&&*(s+1)=='0'&&*(s+2)=='\0'){return 0.0f;}
    else if(*s=='-'&&*(s+1)=='0'&&*(s+2)=='\0'){return -0.0f;}

    if(isfnum(s))
    {
        if(compare(s,"340282346638528859811704183484516925440.000000")==1){return FLT_MAX;}
        else if(compare(s,"-340282346638528859811704183484516925440.000000")==-1){return -FLT_MAX;}
        double ans=0;
        float final_ans=0;
        int k=0;
        int flag=0;
        while(k<strlen(s)&&s[k]!='.')
        {
            if(isdigit(s[k]))
            {
                ans=ans*10+(s[k]-'0');
                final_ans=final_ans*10+(s[k]-'0');
            }
            else
            {
                if(s[k]=='-'){flag=1;}
            }
            k++;
        }
        k++;
        float base=0.1;
        while(k<strlen(s))
        {
            if(isdigit(s[k]))
            {
                ans+=(s[k]-'0')*base;
                final_ans+=(s[k]-'0')*base;
            }
            base*=0.1;
            k++;
        }
        if(flag==1){ans=-ans;final_ans=-final_ans;}

        return final_ans;
    }
    else if(isenum(s))
    {
        int meet=0;
        int need=0;
        int number=0;
        int is=0;
        if(*s=='-'){is++;}
        else if(*s=='+'||isdigit(*(s+1))){is++;}
        const char * s_start=s+is;
        for(int i=0;i<strlen(s);i++)
        {
            if(*(s+i)=='e'||*(s+i)=='E'){meet=i;break;}
        }
        int s_before_e_len=meet-is;
        char news[s_before_e_len+3];
        if(*(s+meet+1)=='-'){need=-1;}
        else if(*(s+meet+1)=='+'||isdigit(*(s+meet+1))){need=1;}
        for(int i=meet+1;i<strlen(s);i++)
        {
            if(isdigit(*(s+i))){number=number*10+(*(s+i)-'0');}
        }
        if(need==-1&&s_before_e_len-number>0)
        {
            for(int i=0;i<meet-number;i++){news[i]=*(s+i);}
            news[meet-number]='.';
            for(int i=meet-number+1;i<s_before_e_len+2;i++){news[i]=*(s+i-1);}
            news[s_before_e_len+2]='\0';
        }
        for(int i=0;i<s_before_e_len+3;i++){printf("%c",news[i]);}
        printf("\n");
        return cs_atof(news);
    }
}

int main()
{
    // 测试用例数组
    char *test_cases[] =
    {
        "",
        "INF",
        "-INF",
        "0",
        "+0",
        "-0",
        "128",
        "0.1",
        "0.5",
        "0.005",
        "123.56",
        "-123456e-4",
        "340282346638528859811700000000000000000.000000",
        "340282356638528859811704183484516925440.000000",
        "-340282366638528859811704183484516925440.000000",
        "340282346638528859811704183484516925440.000000",
    };
    for (int i=0;i<16;i++)
    {
        char *input = test_cases[i];
        float result = cs_atof(input);
        printf("Input: \"%s\"\n", input);
        printf("Output: ");
        if(input==NULL){return 0.0f;}
        if(*input=='I'&&*(input+1)=='N'&&*(input+2)=='F'){printf("%f\n",(float)INFINITY);}
        if(*input=='-'&&*(input+1)=='I'&&*(input+2)=='N'&&*(input+3)=='F'){printf("%f\n",-(float)INFINITY);}
        else if (result == 0.0f && !isinf(result))
        {
            if (1.0f / result < 0.0f) {printf("-0.000000\n"); }
            else {printf("0.000000\n"); }
        }
        else {printf("%f\n", result); }
    }
    return 0;
}
