#include <stdio.h>
#include <wchar.h>
#include <stdbool.h>
bool check16(char *s)
{
    if(*s=='0'&&*(s+1)=='x'&&isdigit(*(s+2))&&isdigit(*(s+3)))return 1;
    return 0;
}
int utf8len(char *s)
{
	int count=0;
    unsigned char *p = (unsigned char *)s;
	while (*p!='\0')
	{
        if(count==0&&(*p & 0b11000000)==0b10000000){return -1;}
	    if ((*p & 0b10000000) == 0) // 最高位是0，是单字节ASCII
	    {
		count++;
		p++;
	    }
	    else if ((*p & 0b11100000) == 0b11000000) // 最高三位是110，是2字节字符
	    {
	    if (*(p+1) == '\0' || (*(p+1)& 0b11000000) != 0b10000000) {return -1;}
		count++;
		p += 2;
	    }
	    else if ((*p & 0b11110000) == 0b11100000) // 最高四位是1110，是3字节字符
	    {
	    if(*(p+1) == '\0' || *(p+2) == '\0' || (*(p+1) & 0b11000000) != 0b10000000|| (*(p+2)& 0b11000000) != 0b10000000) {return -1;}
		count++;
		p += 3;
	    }
	    else if ((*p & 0b11111000) == 0b11110000) // 最高五位是11110，是4字节字符
	    {
	    if(*(p+1) == '\0' || *(p+2) == '\0' || *(p+3) == '\0' ||(*(p+1) & 0b11000000) != 0b10000000||(*(p+2) & 0b11000000) != 0b10000000|| (*(p+3)& 0b11000000) != 0b10000000) {return -1;}
		count++;
		p += 4;
	    }
	    else {p++;}
	}
	return count;
}
int main()
{
	char *s0="";
    char *s1="1";
    char  s2[100]={0xde,0xc2,0};
    char *s3="我";
    char *s4=" ";
    char *s5="a21  我们123";
    char  s6[100]={0x80,0};
    char  s7[100]={'1',   0xc1,0x82,   0xe2,0x80,0x81,    0xf1,0x81,0x82,0x83,   0};
    char  s8[100]={0x91,0x89,0};
    char  s9[100]={0xfc,0x82,0x83,0x84,0};
    char  s10[100]={0xde,0xa2,0};

	int ans0=utf8len(s0);
	int ans1=utf8len(s1);
	int ans2=utf8len(s2);
	int ans3=utf8len(s3);
	int ans4=utf8len(s4);
	int ans5=utf8len(s5);
	int ans6=utf8len(s6);
	int ans7=utf8len(s7);
	int ans8=utf8len(s8);
	int ans9=utf8len(s9);
	int ans10=utf8len(s10);
	printf("s0 answer is %d\n",ans0);
	printf("s2 answer is %d\n",ans1);
	printf("s3 answer is %d\n",ans2);
	printf("s4 answer is %d\n",ans3);
	printf("s5 answer is %d\n",ans4);
	printf("s6 answer is %d\n",ans5);
	printf("s7 answer is %d\n",ans6);
	printf("s7 answer is %d\n",ans7);
	printf("s8 answer is %d\n",ans8);
	printf("s9 answer is %d\n",ans9);
	printf("s10 answer is %d\n",ans10);
	return 0;
}
