#include<stdio.h>
#include <ctype.h>
#include <string.h>
#include <limits.h>
int check(char *s)
{
    int k=0;
    while(k<strlen(s))
    {
        if(k==0)
        {
            if(!isdigit(s[0])&&s[0]!='+'&&s[0]!='-'){return 0;}
        }
        else
        {
            if(!isdigit(s[k])){return 0;}
        }
        k++;
    }
    return 1;
}
int cs_atoi(char *s)
{
    if(!check(s)){return 0;}
    else
    {
        long long ans=0;
        int k=0;
        int flag=0;
        while(k<strlen(s))
        {
            if(isdigit(s[k])){ans=ans*10+(s[k]-'0');}
            else
            {
                if(s[k]='-'){flag=1;}
            }
            k++;
        }
        if(flag==1){ans=-ans;}
        if(ans>=INT_MAX){return INT_MAX;}
        else if(ans<=INT_MIN){return INT_MIN;}
        return ans;
    }
}

int main()
{
    char x[100];
    scanf("%s", x);
    int ans=cs_atoi(x);
    printf("%d\n",ans);
}
