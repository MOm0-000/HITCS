#include <stdio.h>
#include <math.h>
#include<float.h>
void cs_ftoa(float f,char* s)
{
    if(isnan(f)){strcpy(s,"nan");return;}
    if(f==INFINITY){strcpy(s,"inf");return;}
    if(f==-INFINITY){strcpy(s,"-inf");return;}
    if(f>=FLT_MAX){strcpy(s,"340282346638528859811704183484516925440.000000");return;}
    if(f==0.0f)
    {
        unsigned int bits;
        memcpy(&bits, &f, 4);
        if(bits& 0x80000000){strcpy(s,"-0.000000");}
        //if(bits& 0b10000000000000000000000000000000){strcpy(s,"-0.000000");}
        else{strcpy(s,"0.000000");}
        return;
    }
    int isneg=0;
    long long x=(long long)f;

    float F0=f-x;
    //printf("%f\n",F0);
    int digits[7];
    float temp = F0;
    for (int i = 0; i < 7; i++)
    {
        temp *= 10.0f;
        int d = (int)temp;
        digits[i] = d;
        temp -= (float)d;
    }
    // 四舍五入：从第6位开始（索引5），看第7位（索引6）
    if (digits[6] >= 5)
    {
        digits[5]++;
        // 处理进位（向高位）
        for (int i = 5; i >= 0; i--)
        {
            if (digits[i] < 10) break;
            digits[i] = 0;
            if (i == 0)
            {
                // 小数部分进位到整数部分
                x++;
                // 整数部分需重写（本例 int_part 从 0 → 1）
                break;
            } else {digits[i - 1]++;}
        }
    }

    //for(int i=0;i<7;i++){printf("%d ",digits[i]);}
    //printf("\n");

    if(x<0){isneg=1;x=-x;}
    int len=0;
    char tmp[60]={0};
    if(f>=10.0f||f<=-10.0f)
    {
        for(int i=0;i<50;i++)
        {
            if(x==0){break;}
            tmp[i]=(x%10)+'0';
            x/=10;
            len++;
        }
        if(isneg==1)
        {
            len++;tmp[len-1]='-';
        }
        for(int i=0;i<len;i++)
        {
            s[i]=tmp[len-1-i];
        }
        len++;
        s[len-1]='.';
    }
    else
    {
        if(!isneg){s[0]=x+'0';s[1]='.';len++;len++;}
        if(isneg){s[0]='-';s[1]=x+'0';s[2]='.';len++;len++;len++;}
    }

    for(int i=0;i<6;i++)
    {
        len++;
        s[len-1]=digits[i]+'0';
    }
    s[len]='\0';
}
int main() {
    char buffer[100];
    float x[15] =
    {
        NAN,
        INFINITY,
        -INFINITY,
        -0.0f,
        0.0f,
        1.0f,
        -1.0f,
        128.0f,
        0.1f,
        0.5f,
        0.005f,
        123.56f,
        340282346638528859811700000000000000000.0f,
        340282356638528859811704183484516925440.0f,
        FLT_MAX,
    }; //-340282366638528859811704183484516925440.0f is out of range
    for (int i = 0; i < 15; i++)
    {
        float input = x[i];
        printf("Input: \"%f\"\n", input);
        printf("Output: ");
        cs_ftoa(x[i],buffer);
        printf("%s\n", buffer);
    }
    return 0;
}
