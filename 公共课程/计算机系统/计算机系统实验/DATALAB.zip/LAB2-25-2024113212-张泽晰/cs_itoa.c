#include <stdio.h>
#include<limits.h>
void cs_itoa(int x,char* s)
{
    int isneg=0;
    if(x<0){isneg=1;}
    if(x!=INT_MIN&&isneg==1){x=-x;}
    else if(x==INT_MIN){strcpy(s, "-2147483648");return;}
    else if(x==0){strcpy(s,"0");return;}
    int len=0;
    char tmp[15]={0};
    for(int i=0;i<15;i++)
    {
        if(x==0){break;}
        tmp[i]=(x%10)+'0';
        x/=10;
        len++;
    }
    if(isneg==1)
    {
        len++;tmp[len-1]='-';
    }
    for(int i=0;i<len;i++)
    {
        s[i]=tmp[len-1-i];
    }
    s[len]='\0';
}
int main() {
    char buffer[32];
    int x[6] =
    {
        0,
        -1,
        1,
        INT_MAX,
        INT_MIN,
        -1234567890,
    };
    for (int i = 0; i < 6; i++)
    {
        int input = x[i];
        printf("Input: \"%d\"\n", input);
        printf("Output: ");
        cs_itoa(x[i],buffer);
        printf("%s\n", buffer);
    }
    return 0;
}
