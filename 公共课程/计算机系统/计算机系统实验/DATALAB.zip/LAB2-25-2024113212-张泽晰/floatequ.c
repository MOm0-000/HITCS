#include <stdio.h>
int main()
{
	float a = 646616.10;
	float b = 234732.45;

	float c = a + b;
	float target =881348.55;

	printf("%.2lf\n", a);
	printf("%.2lf\n", b);
	printf("%.2lf\n", c);

	if (c == target)
		printf("OK!\n");
	else
		printf("Error!\n");
}
