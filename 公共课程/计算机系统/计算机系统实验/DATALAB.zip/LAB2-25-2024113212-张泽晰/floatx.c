#include<stdio.h>
#include<float.h>
#include<math.h>
#include <string.h> // memcpy

void print_float_bytes(float f)
{
    unsigned char bytes[sizeof(float)];
    memcpy(bytes, &f, sizeof(float));

    // 小端序
    for (int i = 0; i < sizeof(float); i++) {printf("%02X", bytes[i]);}
    printf(" ");
}
int main()
{
    float x[7] =
    {
        0.0f,
        -0.0f,
        FLT_TRUE_MIN,
        FLT_MAX,
        FLT_MIN,
        INFINITY,
        NAN,
    };
    for(int i=0;i<7;i++)
    {
        print_float_bytes(x[i]);
        printf("%g\n",x[i]);
    }
    return 0;
}
